export class Book {

    bookId: number | undefined;
    userId: number | undefined;
    isbn: String | undefined;
    title: String | undefined;
    author: String | undefined;
    genre: String | undefined;
    publisher: String | undefined;
    cost: number | undefined;

}
