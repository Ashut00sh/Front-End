export class User {

    userId: number | undefined;
	userName: string | undefined;
	password: string | undefined;
	emailId: string | undefined;
	mobileNo: number | undefined;
	gender: string | undefined;
	city: string | undefined;
	pincode: number | undefined;
}
