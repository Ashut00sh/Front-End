import { ExchangeRequest } from './exchange-request';

describe('ExchangeRequest', () => {
  it('should create an instance', () => {
    expect(new ExchangeRequest()).toBeTruthy();
  });
});
